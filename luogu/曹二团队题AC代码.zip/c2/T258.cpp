#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
	int cnt;
	cin >> cnt;

	int i;
	for (i = 0; i < cnt; ++i)
	{
		cout << "wang";
	}
	return 0;
}