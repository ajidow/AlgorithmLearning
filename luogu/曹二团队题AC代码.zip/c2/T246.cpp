#include <iostream>
#include <cstdio>
using namespace std;

int main(int argc, char const *argv[])
{
	int i;

	cin >> i;

	if (i % 2 == 0)
	{
		cout <<"Even";
	}else{
		cout <<"Odd";
	}
	return 0;
}