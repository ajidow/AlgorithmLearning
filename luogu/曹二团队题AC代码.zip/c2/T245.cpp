#include <iostream>
#include <cstdio>
using namespace std;

int main(int argc, char const *argv[])
{
	int a,b,c;

	cin >> a >> b >> c;
	cout << (b*b) - 4*a*c;
	return 0;
}