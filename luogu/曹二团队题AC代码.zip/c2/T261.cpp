#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{

	int a,b;
	cin >> a >> b;

	for (int i = a; i <= b; ++i)
	{
		cout << i << " ";
	}

	return 0;
}