#include <iostream>
#include <cstdio>
using namespace std;

int main(int argc, char const *argv[])
{
	int n;

	cin >> n;

	for (int i = 1; i <= n; ++i)
	{
		cout << i << " ";
	}
	return 0;
}