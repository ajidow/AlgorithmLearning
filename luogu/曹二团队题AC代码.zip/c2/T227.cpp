#include <cstdio>
#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
	double a,b;
	cin >> a >> b;

	printf("%.6lf",a/b);

	return 0;
}