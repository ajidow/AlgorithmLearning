#include <iostream>

using namespace std;
int main(void)
{
	int money;
	cin >> money;
	if(money > 100)
	{
		cout << "i am lucky " <<  money;
	}else{
		cout << "just so so";
	}
	
	return 0;
	
}