#include <iostream>
int main(void)
{
	int left,right;
	cin >> left >> right;
	if( left > right )
	{
		cout << "Left " << left;
	}else{
		cout << "Right " << right;
	}
	
	return 0;
	
}